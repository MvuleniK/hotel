import React from 'react';
import './Dashboard.css';




function Dashboard() {
  return (
    <div class>
        Dashboard
    </div>
  )
}

export default Dashboard;